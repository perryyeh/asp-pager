CREATE PROCEDURE SP_ShowoPage

  @Showo_CurrPage	INT,
  @Showo_PageSize	INT,
  @Showo_Field		VARCHAR(800),
  @Showo_Table		VARCHAR(50),
  @Showo_Where		VARCHAR(800),
  @Showo_WhereOther	VARCHAR(800),
  @Showo_OrderBy	VARCHAR(800),
  @Showo_Id		VARCHAR(50),
  @Showo_Size		VARCHAR(3),
  @Showo_Order		VARCHAR(5)

AS

SET NOCOUNT ON
DECLARE @SQL NVARCHAR(4000)

IF @Showo_CurrPage=1
  SET @SQL='SELECT TOP '+CAST(@Showo_PageSize AS VARCHAR)+' '+@Showo_Field+' FROM '+@Showo_Table+@Showo_Where+' '+@Showo_OrderBy
ELSE
  SET @SQL='SELECT TOP '+CAST(@Showo_PageSize AS VARCHAR)+' '+@Showo_Field+' FROM '+@Showo_Table+' WHERE '+@Showo_Id+@Showo_Order+'(SELECT '+@Showo_Size+'('+@Showo_Id+')  FROM (SELECT TOP '+CAST(@Showo_PageSize*(@Showo_CurrPage-1) AS VARCHAR)+' '+@Showo_Id+' FROM '+@Showo_Table+@Showo_Where+' '+@Showo_OrderBy+') AS tmpTable) '+@Showo_WhereOther+' '+@Showo_OrderBy

EXEC(@SQL)
GO