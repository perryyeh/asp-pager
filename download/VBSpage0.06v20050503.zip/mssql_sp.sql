CREATE PROCEDURE SP_ShowoPage

  @iPageCurr	INT,
  @iPageSize	INT,
  @sField	VARCHAR(800),
  @sTable	VARCHAR(50),
  @sCond2	VARCHAR(800),
  @sCond1	VARCHAR(800),
  @sOrderBy	VARCHAR(800),
  @sPkey		VARCHAR(50),
  @sSize		VARCHAR(3),
  @iOrderBy		VARCHAR(5)

AS

SET NOCOUNT ON
DECLARE @SQL NVARCHAR(4000)

IF @iPageCurr=1
  SET @SQL='SELECT TOP '+CAST(@iPageSize AS VARCHAR)+' '+@sField+' FROM '+@sTable+@sCond2+' '+@sOrderBy
ELSE
  SET @SQL='SELECT TOP '+CAST(@iPageSize AS VARCHAR)+' '+@sField+' FROM '+@sTable+' WHERE '+@sPkey+@iOrderBy+'(SELECT '+@sSize+'('+@sPkey+')  FROM (SELECT TOP '+CAST(@iPageSize*(@iPageCurr-1) AS VARCHAR)+' '+@sPkey+' FROM '+@sTable+@sCond2+' '+@sOrderBy+') AS tmpTable) '+@sCond1+' '+@sOrderBy

EXEC(@SQL)
GO